//
//  TableViewCellCategoria.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 30/05/22.
//

import UIKit

class TableViewCellCategoria: UITableViewCell {

    @IBOutlet weak var txt: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var imagen: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        //img().frame(width: 100, height: 100)
    }
    
}
