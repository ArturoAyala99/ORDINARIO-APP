//
//  CategoryViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import UIKit

class CategoryViewController: UIViewController {
    
    var userLoged: String = "1";
    var categorias = [Categoria]()
    
    @IBOutlet weak var categoryCollection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseData()
        categoryCollection.dataSource = self
        categoryCollection.delegate = self
        categoryCollection.collectionViewLayout = UICollectionViewFlowLayout()
        categoryCollection.contentInset = UIEdgeInsets(top: 30, left: 20, bottom: 10, right: 20)

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    func parseData(){
            let url =  "http://localhost:8000/rating"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "GET"
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        let categoriastemp = fetchedData.value(forKey: "data")  as! NSArray
                        //print(categoriastemp)
                        for element in categoriastemp{
                            
                            
                            let categoria = element as! [String:Any]
                            let nombre = categoria["name"]
                            
                            let id = categoria["id"]
                            let imagen = categoria["image"]
                            self.categorias.append(Categoria(id: id as! Int, nombre: nombre as! String, imagen: imagen as! String))
                        }
                        self.categoryCollection.reloadData()
                    }
                    catch{
                        
                    }
                }
            }
            task.resume()
        }
    
}




extension CategoryViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "vcItems") as! ItemsViewController
        vc.categoriePassed = String(categorias[indexPath.row].id)
        vc.userLoged = userLoged
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categorias.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = categoryCollection.dequeueReusableCell(withReuseIdentifier: "RoundedCollectionViewCell", for: indexPath) as! RoundedCollectionViewCell
        cell.categorieText.text = categorias[indexPath.row].nombre
        if let url = URL(string: categorias[indexPath.row].imagen ){
            do{
                let data = try Data(contentsOf: url)
                cell.imageCategorie.image = UIImage(data: data)
            }
            catch{
                print("Error imagen")
            }
        }
        return cell
    }
}


extension CategoryViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:150, height: 270)
    }
    
}





