//
//  Cart.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import Foundation

class Carrito {
    var id: Int
    var user: Int
    var product: Int
    var quantity: Int
    var name: String
    var image: String
    var price: Int

    
    init(id:Int, user: Int, product:Int,Quantity:Int, name: String,image: String,  price: Int){
        self.id = id
        self.user = user
        self.product = product
        self.quantity = Quantity
        self.name = name
        self.image = image
        self.price = price
    }
}

