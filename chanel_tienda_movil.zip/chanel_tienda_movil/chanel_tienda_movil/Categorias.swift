//
//  Categorias.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 30/05/22.
//

import Foundation

class Categoria {
    var id: Int
    var nombre: String
    var imagen: String
    
    init(id: Int, nombre: String, imagen: String) {
        self.id = id
        self.nombre = nombre
        self.imagen = imagen
    }
    
}
