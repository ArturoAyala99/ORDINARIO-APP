//
//  ItemsViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import UIKit

class ItemsViewController: UIViewController {
    
    var categoriePassed : String = "1"
    var userLoged:String = "1";
    var items = [Item]()
    
    @IBOutlet weak var itemCollection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseData()
        itemCollection.dataSource = self
        itemCollection.delegate = self
        itemCollection.collectionViewLayout = UICollectionViewFlowLayout()

        // Do any additional setup after loading the view.
    }
    

    
    
    
    func parseData(){
            let url =  "http://localhost:8000/videogames"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "GET"
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        let itemstemp = fetchedData.value(forKey: "data")  as! NSArray
                        
                        for element in itemstemp{
                            
                            
                            let item = element as! [String:Any]
                            let nombre = item["name"]
                            
                            let id = item["id"]
                            let imagen = item["image"]
                            let description = item["genre"]
                            let price = item["price"]
                            let categorie = String(item["rating_id"] as! Int)
                            
                            if categorie == categoriePassed{
                                self.items.append(Item(id: id as! Int, nombre: nombre as! String, imagen: imagen as! String, descripcion: description as! String, precio: price as! Int))
                            }
                            
                        }
                        self.itemCollection.reloadData()
                    }
                    catch{
                        
                    }
                }
            }
            task.resume()
        }
    
    

}



extension ItemsViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "itemIndiviual") as! IndividualViewController
        vc.itemId = (items[indexPath.row].id)
        vc.userAct = userLoged
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = itemCollection.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as! itemViewCell
        print(items[indexPath.row].nombre)
        cell.itemName.text = items[indexPath.row].nombre
        cell.itemDescription.text = items[indexPath.row].description
        cell.itemPrice.text = "$" + String(items[indexPath.row].precio)
        if let url = URL(string: items[indexPath.row].imagen ){
            do{
                let data = try Data(contentsOf: url)
                cell.itemImage.image = UIImage(data: data)
            }
            catch{
                print("Error imagen")
            }
        }
        return cell
    }
}






extension ItemsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:180, height: 300)
    }
    
}

