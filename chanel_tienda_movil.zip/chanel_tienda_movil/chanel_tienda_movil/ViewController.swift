//
//  ViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 25/05/22.
//

import UIKit

class ViewController: UIViewController {

    var usertemp : String = "";
    @IBOutlet weak var textUser: UITextField!
    @IBOutlet weak var textPwd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func irARegistro(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "vcRegistro") as! RegisterViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
    
    
    
    
    @IBAction func inicarSesion(_ sender: Any) {
        
        if textUser.text=="" || textPwd.text=="" {
            let uialert = UIAlertController(title: "", message: "Llena los campos", preferredStyle: UIAlertController.Style.alert)
                  uialert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
               self.present(uialert, animated: true, completion: nil)
        }else{
        parseData()
        }
        
    }
    
    
    
    
    
    func parseData(){
        
            let url =  "http://localhost:8000/user/get"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "POST"
            let body: [String: AnyHashable] = [
                "user_username": "\(textUser.text ?? "")",
                "user_password": "\(textPwd.text ?? "")"
            ]
        print(body)
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        usertemp = fetchedData.value(forKey: "status") as! String
                       
                        //print (actUser["username"] as! String)
                        
                        if usertemp == "conectado" {
                            let actUser = fetchedData.value(forKey: "data") as! [String:Any]
                            let vc = storyboard?.instantiateViewController(withIdentifier: "vcCategoria") as! CategoryViewController
                            vc.userLoged = String(actUser["id"] as! Int)
                            vc.modalPresentationStyle = .fullScreen
                            present(vc, animated: true)
                            
                        }else {
                            print(usertemp)
                            let uialert = UIAlertController(title: "ERROR", message: "Datos incorrectos", preferredStyle: UIAlertController.Style.alert)
                                  uialert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                               self.present(uialert, animated: true, completion: nil)
                            print("Acceso denegado")
                            
                        }
                        
                        
                        
                    }
                    catch{
                        print("Error")
                    }
                }
            }
            task.resume()
            
        }
    
    
    
    


}

