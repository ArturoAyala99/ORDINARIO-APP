//
//  RegisterViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var textUser: UITextField!
    @IBOutlet weak var textEmail: UITextField!
    @IBOutlet weak var textPwd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    @IBAction func volverLogin(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "vcLogin") as! ViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    
    
    
    @IBAction func registrar(_ sender: Any) {
        
        if textUser.text=="" || textPwd.text=="" || textEmail.text=="" {
            let uialert = UIAlertController(title: "", message: "llena los campos", preferredStyle: UIAlertController.Style.alert)
                  uialert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
               self.present(uialert, animated: true, completion: nil)
            
            
            let vc = storyboard?.instantiateViewController(withIdentifier: "vcLogin") as! ViewController
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
            
        }else{
        parseData()
        }
        
    }
    
    
    
    
    func parseData(){
        
            let url =  "http://localhost:8000/user/register"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "POST"
            let body: [String: AnyHashable] = [
                "user_username": "\(textUser.text ?? "")",
                "user_password": "\(textPwd.text ?? "")",
                "user_email": "\(textEmail.text ?? "")"
            ]
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        
                        
                        let uialert = UIAlertController(title: "", message: (fetchedData.value(forKey: "message") as! String), preferredStyle: UIAlertController.Style.alert)
                              uialert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: nil))
                           self.present(uialert, animated: true, completion: nil)
                        
                        
                        
                        
                        
                    }
                    catch{
                        print("Error")
                    }
                }
            }
            task.resume()
            
        }
    
    
    
    
    

}
