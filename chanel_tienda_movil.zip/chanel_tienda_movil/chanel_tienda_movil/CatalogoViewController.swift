//
//  CatalogoViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 27/05/22.
//

import UIKit

class CatalogoViewController: UIViewController {
    
    @IBOutlet weak var tablaCatalogo: UITableView!
    var userLoged: String = "1"
    
    var categorias = [Categoria]()
    
        override func viewDidLoad() {
            super.viewDidLoad()
            parseData()
            tablaCatalogo.dataSource = self
            tablaCatalogo.delegate = self
            
    }
    
    
    
    
    func parseData(){
            let url =  "http://localhost:8000/rating"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "GET"
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        let categoriastemp = fetchedData.value(forKey: "data")  as! NSArray
                        //print(categoriastemp)
                        for element in categoriastemp{
                            
                            
                            let categoria = element as! [String:Any]
                            let nombre = categoria["name"]
                            
                            let id = categoria["id"]
                            let imagen = categoria["image"]
                            self.categorias.append(Categoria(id: id as! Int, nombre: nombre as! String, imagen: imagen as! String))
                        }
                        self.tablaCatalogo.reloadData()
                    }
                    catch{
                        
                    }
                }
            }
            task.resume()
        }

}



extension CatalogoViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ItemsViewController
        //vc.stringPassed = String(categorias[indexPath.row].id)
        //navigationController?.pushViewController(vc, animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categorias.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablaCatalogo.dequeueReusableCell(withIdentifier: "TableViewCellCategoria", for: indexPath) as! TableViewCellCategoria
        cell.txt.text = categorias[indexPath.row].nombre
        if let url = URL(string: categorias[indexPath.row].imagen ){
            do{
                let data = try Data(contentsOf: url)
                cell.img.image = UIImage(data: data)
            }
            catch{
                print("Error imagen")
            }
        }
        return cell
    }
}


