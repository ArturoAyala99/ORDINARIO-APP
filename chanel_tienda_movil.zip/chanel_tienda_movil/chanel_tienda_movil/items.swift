//
//  items.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import Foundation


class Item {
    var id: Int
    var nombre: String
    var imagen: String
    var description: String
    var precio: Int

    
    init(id:Int, nombre: String, imagen: String, descripcion: String, precio: Int){
        self.id = id
        self.nombre = nombre
        self.imagen = imagen
        self.description = descripcion
        self.precio = precio
    }
}



