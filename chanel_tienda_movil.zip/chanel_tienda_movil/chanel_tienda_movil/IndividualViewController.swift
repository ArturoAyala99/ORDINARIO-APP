//
//  IndividualViewController.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import UIKit

class IndividualViewController: UIViewController {
    
    var itemId: Int = 1
    var userAct: String = ""
    var nameItem: String = ""
    var priceItem: String = ""
    var imageURL: String = ""
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemQuantity: UITextField!
    @IBOutlet weak var itemStepper: UIStepper!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseData()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    
    func parseData(){
        
            let url =  "http://localhost:8000/videogame/get/" + String(itemId)
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "GET"
            //request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
                        let item = fetchedData.value(forKey: "data") as! [String:Any]
                        //print (actUser["username"] as! String)
                        
                        nameItem = item["name"] as! String
                        priceItem = String(item["price"] as! Int)
                        imageURL = item["image"] as! String
                        if let url = URL(string: item["image"] as! String ){
                            do{
                                let img = try Data(contentsOf: url)
                                itemImage.image = UIImage(data: img)
                            }
                            catch{
                                print("Error imagen")
                            }
                        }
                        
                        
                        
                        
                    }
                    catch{
                        print("Error")
                    }
                }
            }
            task.resume()
            
        }
    
    
    
    
    
    
    func cartData(){
        
            let url =  "http://localhost:8000/cart/insert"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "POST"
            let body: [String: AnyHashable] = [
                "cart_user_id": "\(userAct)",
                "cart_videogame_id": "\(String(itemId))",
                "cart_quantity": "\(itemQuantity.text ?? "")",
                "cart_videogame_name": "\(nameItem)",
                "cart_videogame_image": "\(imageURL)",
                "cart_videogame_price": "\(priceItem)"
                
            ]
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    do{
                    
                        let fetchedData = try JSONSerialization.jsonObject(with: data!, options: . mutableLeaves) as! NSObject
    
                        let status = fetchedData.value(forKey: "success") as! String
                        print (status)
                    }
                    catch{
                        print("Error")
                    }
                }
            }
            task.resume()
            
        }
    
    
    @IBAction func agregarAlCarrito(_ sender: Any) {
        cartData()
    }
    
    
    @IBAction func stepperCounter(_ sender: Any) {
        itemQuantity.text = String(Int(itemStepper.value))
    }
    

}
