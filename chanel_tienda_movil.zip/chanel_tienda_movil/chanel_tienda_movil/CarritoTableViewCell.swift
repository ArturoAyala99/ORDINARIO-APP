//
//  CarritoTableViewCell.swift
//  chanel_tienda_movil
//
//  Created by Rodrigo Yerena on 09/06/22.
//

import UIKit

class CarritoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageCart: UIImageView!
    @IBOutlet weak var productCart: UILabel!
    @IBOutlet weak var quantityCart: UILabel!
    @IBOutlet weak var priceCart: UILabel!
    var idcar: Int = 1
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
   
    
    
    
    func parseData(){
        
            let url =  "http://localhost:8000/cart/delete"
            var request = URLRequest(url: URL(string: url)!)
            request.httpMethod = "DELETE"
            let body: [String: AnyHashable] = [
                "cart_id": "\(idcar)",
               
                
            ]
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: nil,delegateQueue: OperationQueue.main)
            let task = session.dataTask(with: request) { [self] (data, response, error) in
                if(error != nil){
                    print("Error")
                }else {
                    
                }
            }
            task.resume()
            
        }
    
    
    

}
